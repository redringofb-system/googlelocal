/**
 * @enum {number}
 */
export const GEO_IN_GROUP = {
  NOT_DEFINED: 1,
  IN: 2,
  NOT_IN: 3,
};
